# 🛣️ RoadTrip Planner AI v3

Aplicação para planejamento de road trips com rotas, clima, camping (iOverlander), pontos turísticos, controle financeiro, conversão de moedas e assistente IA.

## Rodar em 2 comandos

```bash
npm install
npm run dev
```

Abre em **http://localhost:5173**

## Deploy

```bash
npm run build
```

A pasta `dist/` gerada pode ser deployada em:
- **Vercel**: conecte o GitHub e deploy automático
- **Netlify**: arraste a pasta `dist/` em app.netlify.com/drop
- **Railway**: conecte GitHub em railway.com

## APIs

Copie `.env.example` para `.env` e preencha as chaves:

| Serviço | Free Tier | Para quê |
|---------|-----------|----------|
| Google Maps | $200/mês crédito | Mapas e rotas |
| OpenWeather | 1.000 calls/dia | Previsão do tempo |
| ExchangeRate-API | 1.500 calls/mês | Cotações moedas |
| Google Places | Com Google Maps | Pontos turísticos |
| Anthropic Claude | Pago por uso | Chat IA |
| iOverlander | Download JSON | Camping e paradas |

## Stack

React 18 + Vite 5 · CSS puro · Zero dependências externas
